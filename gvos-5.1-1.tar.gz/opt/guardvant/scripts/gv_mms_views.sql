if object_id('gvEnum','V') is not null drop view gvEnum;
create view gvEnum as
select Id, EnumTypeId, Idx, Description, Abbreviation, Flags
  from MMS.Enum;

if object_id('gvEnumType','V') is not null drop view gvEnumType;
create view gvEnumType as
select Id, Name
  from MMS.EnumType;

if object_id('gvRootPit','V') is not null drop view gvRootPit;
create view gvRootPit as
select FieldGrClock as grclock,
       FieldDispTime as disptime,
       FieldShiftCount as shiftcount,
       FieldShiftStart as shiftstart,
       FieldShiftLen as shiftlen,
       s.Idx as dispshift,
       c.Idx as dispcrew
  from MMS.PitRootEtc
  left join MMS.Enum s on s.Id = FieldDispShift
  left join MMS.Enum c on c.Id = FieldDispCrew;

if object_id('gvRootShift','IF') is not null drop function gvRootShift;
create function gvRootShift(@id bigint)
returns table as return
select r.Id,
       FieldStart as [start],
       FieldTime as [time],
       FieldYear as [year],
       m.Idx as [month],
       FieldDay as [day],
       s.Idx as [shift],
       c.Idx as [crew],
       FieldHoliday as [holiday]
  from MMS.SHIFTRootShiftdate r
  left join MMS.Enum m on m.Id = FieldMonth
  left join MMS.Enum s on s.Id = FieldShift
  left join MMS.Enum c on c.id = FieldCrew
 where @id is null or r.Id = @id;

if object_id('gvTruck','V') is not null drop view gvTruck;
create view gvTruck as
select t.Id,
       FieldId as record_name,
       DbVersion as revision,
       s.Idx as status,
       u.Idx as unit,
       FieldXloc as xloc,
       FieldYloc as yloc,
       FieldLoc as loc,
       FieldExcav as excav,
       FieldLocnext as locnext,
       an.Idx as actnext,
       un.Idx as unitlocnext,
       l.Idx as load
  from MMS.PITTruck t
  left join MMS.Enum s on s.Id = FieldStatus
  left join MMS.Enum u on u.Id = FieldUnit
  left join MMS.Enum an on an.Id = FieldActnext
  left join MMS.Enum un on un.Id = FieldUnitlocnext
  left join MMS.Enum l on l.Id = FieldLoad;

if object_id('gvExcav','V') is not null drop view gvExcav;
create view gvExcav as
select e.Id,
       FieldId as record_name,
       DbVersion as revision,
       s.Idx as status,
       u.Idx as unit,
       FieldXloc as xloc,
       FieldYloc as yloc,
       FieldLoc as loc,
       FieldExcav as excav,
       FieldLocnext as locnext,
       an.Idx as actnext,
       un.Idx as unitlocnext,
       l.Idx as load
  from MMS.PITExcav e
  left join MMS.Enum s on s.Id = FieldStatus
  left join MMS.Enum u on u.Id = FieldUnit
  left join MMS.Enum an on an.Id = FieldActnext
  left join MMS.Enum un on un.Id = FieldUnitlocnext
  left join MMS.Enum l on l.Id = FieldLoad;

if object_id('gvAuxeqmt','V') is not null drop view gvAuxeqmt;
create view gvAuxeqmt as
select a.Id,
       FieldId as record_name,
       DbVersion as revision,
       s.Idx as status,
       u.Idx as unit,
       FieldXloc as xloc,
       FieldYloc as yloc,
       FieldLoc as loc
  from MMS.PITAuxeqmt a
  left join MMS.Enum s on s.Id = FieldStatus
  left join MMS.Enum u on u.Id = FieldUnit;

if object_id('gvPitloc','V') is not null drop view gvPitloc;
create view gvPitloc as
select p.Id,
       FieldId as record_name,
       DbVersion as revision,
       s.Idx as status,
       u.Idx as unit,
       FieldXloc as xloc,
       FieldYloc as yloc,
       FieldZloc as zloc
  from MMS.PITPitloc p
  left join MMS.Enum s on s.Id = FieldStatus
  left join MMS.Enum u on u.Id = FieldUnit;

if object_id('gvXgraph', 'FN') is not null drop function gvXgraph;
create function gvXgraph(@id bigint)
returns varchar(1024) as
begin
    declare @list varchar(1024)
    select @list = coalesce(@list + ',', '') + cast([Value] as varchar(32))
      from MMS.PITTravelXgraphArray
     where Id = @id
     order by [Index]
    return @list
end;

if object_id('gvYgraph', 'FN') is not null drop function gvYgraph;
create function gvYgraph(@id bigint)
returns varchar(1024) as
begin
    declare @list varchar(1024)
    select @list = coalesce(@list + ',', '') + cast([Value] as varchar(32))
      from MMS.PITTravelYgraphArray
     where Id = @id
     order by [Index]
    return @list
end;

if object_id('gvTravel','V') is not null drop view gvTravel;
create view gvTravel as
select t.Id,
       DbVersion as revision,
       FieldLocstart as locstart,
       FieldLocend as locend,
       dbo.gvXgraph(t.id) as xgraph,
       dbo.gvYgraph(t.id) as ygraph,
       FieldDist as dist,
       FieldClosed as closed
  from MMS.PITTravel t;

if object_id('gvWorkerEqmt', 'FN') is not null drop function gvWorkerEqmt;
create function gvWorkerEqmt(@id bigint)
returns varchar(1024) as
begin
    declare @list varchar(1024)
    select @list = coalesce(@list + ',', '') + cast([Value] as varchar(32))
      from MMS.PITWorkerEqmtArray
     where Id = @id
     order by [Index]
    return @list
end;

if object_id('gvWorkerAuxeqmt', 'FN') is not null drop function gvWorkerAuxeqmt;
create function gvWorkerAuxeqmt(@id bigint)
returns varchar(1024) as
begin
    declare @list varchar(1024)
    select @list = coalesce(@list + ',', '') + cast([Value] as varchar(32))
      from MMS.PITWorkerAuxeqmtArray
     where Id = @id
     order by [Index]
    return @list
end;

if object_id('gvWorker','V') is not null drop view gvWorker;
create view gvWorker as
select w.Id,
       FieldId as record_name,
       DbVersion as revision,
       FieldName as [name],
       dbo.gvWorkerEqmt(w.id) as eqmt,
       dbo.gvWorkerAuxeqmt(w.id) as auxeqmt,
       c.Idx as crew
  from MMS.PITWorker w
  left join MMS.Enum c on c.Id = FieldCrew;

if object_id('gvShifteqmt','IF') is not null drop function gvShifteqmt;
create function gvShifteqmt(@shift_id bigint)
returns table as return
select e.Id,
       FieldId as record_name,
       u.Idx as unit
  from MMS.SHIFTShifteqmt e
  left join MMS.Enum u on u.Id = FieldUnit
 where e.ShiftId = @shift_id;

if object_id('gvShiftaux','IF') is not null drop function gvShiftaux;
create function gvShiftaux(@shift_id bigint)
returns table as return
select e.Id,
       FieldId as record_name,
       u.Idx as unit
  from MMS.SHIFTShiftaux e
  left join MMS.Enum u on u.Id = FieldUnit
 where e.ShiftId = @shift_id;

if object_id('gvShiftloc','IF') is not null drop function gvShiftloc;
create function gvShiftloc(@shift_id bigint)
returns table as return
select e.Id,
       FieldId as record_name,
       u.Idx as unit
  from MMS.SHIFTShiftloc e
  left join MMS.Enum u on u.Id = FieldUnit
 where e.ShiftId = @shift_id;

if object_id('gvShiftoper','IF') is not null drop function gvShiftoper;
create function gvShiftoper(@shift_id bigint)
returns table as return
select o.Id,
       FieldId as record_name,
       FieldEqmt as eqmt,
       FieldAuxeqmt as auxeqmt,
       FieldLogin as login,
       s.Idx as status
  from MMS.SHIFTShiftoper o
  left join MMS.Enum s on s.Id = FieldStatus
 where o.ShiftId = @shift_id;
